#!/bin/sh
php -S 0.0.0.0:${PORT:-8080} 