<?php
// Khởi động ứng dụng
$appRoot = dirname(__DIR__);
require_once $appRoot . '/app/bootstrap.php';

// Khởi tạo Core App
$init = new App; 